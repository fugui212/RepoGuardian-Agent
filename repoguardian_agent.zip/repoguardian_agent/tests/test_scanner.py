from pathlib import Path
import unittest

from repoguardian.scanner import scan_repository


class ScannerTests(unittest.TestCase):
    def test_scanner_detects_sample_security_findings(self):
        root = Path(__file__).resolve().parents[1] / "sample_repo"
        result = scan_repository(root)
        titles = {finding.title for finding in result.findings}
        self.assertIn("Possible API key literal", titles)
        self.assertIn("Dangerous dynamic execution via eval", titles)
        self.assertGreaterEqual(result.metrics["finding_count"], 1)


if __name__ == "__main__":
    unittest.main()
