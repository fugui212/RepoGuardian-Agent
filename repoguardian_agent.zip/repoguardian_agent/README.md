# RepoGuardian Agent

一个面向开发者的 AI 代码库巡检与重构规划 Agent。它会扫描一个本地仓库，识别技术债、安全风险、复杂函数、缺失工程化护栏，并通过多 Agent 工作流生成：

- 代码健康报告 `report.md`
- 可复制到 GitHub Issues 的任务拆分 `issues.json`
- PR/重构执行路线图 `patch_plan.md`
- Agent 决策轨迹 `agent_trace.jsonl`
- 可直接作为 GitHub Pages 展示的静态仪表盘 `index.html`

项目默认可以 **离线运行**，无需 API Key。配置 OpenAI 兼容接口后，会把风险分析、任务拆分、测试设计交给 GPT/MiMo 等底层模型完成。

## 为什么做这个项目

真实团队里，很多代码库的问题不是“没有 AI 写代码”，而是 AI 缺少上下文：不知道哪些文件值得改、哪些风险优先级最高、如何把一次大改拆成可审阅的 PR。RepoGuardian Agent 的目标是把“读代码、找债务、排优先级、生成 PR 计划、补测试”做成一个可重复执行的 Agent 工作流。

## 快速开始

```bash
# 1. 进入项目目录
cd repoguardian_agent

# 2. 离线运行 demo，不需要任何 key
python -m repoguardian scan sample_repo --out artifacts/demo --offline

# 3. 打开本地 demo 仪表盘
python -m repoguardian.demo_server artifacts/demo --port 8000
# 浏览器访问 http://localhost:8000
```

扫描你自己的仓库：

```bash
python -m repoguardian scan /path/to/your/repo --out artifacts/my_repo --offline
```

使用真实 GPT/OpenAI 兼容模型：

```bash
export OPENAI_API_KEY="你的 API Key"
export OPENAI_BASE_URL="https://api.openai.com/v1"   # 也可以换成兼容 Chat Completions 的网关
export OPENAI_MODEL="填写你账号可用的模型名"
python -m repoguardian scan /path/to/your/repo --out artifacts/my_repo
```

## 生成物说明

运行后会在输出目录生成：

| 文件 | 作用 |
| --- | --- |
| `index.html` | 静态 dashboard，可用于 GitHub Pages 展示 |
| `report.md` | 代码健康总结、风险列表、Agent 输出 |
| `issues.json` | GitHub Issue 风格的任务拆分 |
| `patch_plan.md` | 可执行的 PR 路线图 |
| `scan.json` | 扫描得到的结构化数据 |
| `agent_trace.jsonl` | 每个 Agent 的输入、输出、模式、耗时、token 估算 |

## Agent 工作流

```mermaid
flowchart LR
  A[Repository Scanner] --> B[Code Map]
  B --> C[Risk Analyst Agent]
  C --> D[Patch Planner Agent]
  D --> E[Test Designer Agent]
  E --> F[Dashboard / GitHub Issues / PR Plan]
```

1. **Repository Scanner**：扫描源代码、统计文件/语言/LOC，定位 TODO、危险调用、硬编码密钥、裸 `except`、长函数、缺失 CI 等问题。
2. **Risk Analyst Agent**：把扫描结果压缩成风险画像，判断哪些问题应该优先修复。
3. **Patch Planner Agent**：把高风险发现拆成 GitHub Issue、PR 顺序、验收标准和回滚边界。
4. **Test Designer Agent**：根据风险类型生成测试策略，减少 Agent 自动改代码时的回归风险。
5. **Report Renderer**：输出 Markdown、JSON、HTML Dashboard，方便提交评估或继续接入 GitHub API。

## 证据截图

本压缩包已经包含一组可上传到申请表第 05 项的证明材料：

- `screenshots/terminal_run.png`：终端运行日志截图
- `screenshots/workflow_dashboard.png`：Agent 工作流/仪表盘截图
- `evidence/terminal_run.log`：真实 CLI 运行日志
- `docs/index.html`：GitHub Pages 就绪的静态 demo 页面

> GitHub 项目链接需要你上传仓库后获得，不能用假的。上传后可以在申请表中填写：`https://github.com/<你的用户名>/repoguardian_agent`。如果启用 GitHub Pages，可以填写：`https://<你的用户名>.github.io/repoguardian_agent/`。

## 项目结构

```text
repoguardian_agent/
├── repoguardian/              # Agent 与扫描器源码
├── sample_repo/               # 用于演示的待扫描代码库
├── scripts/                   # 一键运行脚本
├── screenshots/               # 申请表可上传截图
├── evidence/                  # 运行日志
├── docs/                      # GitHub Pages 静态页面
├── tests/                     # 单元测试
└── artifacts/demo/            # demo 运行生成物
```

## 后续可扩展方向

- 接入 GitHub REST API，自动创建 Issue、草拟 PR 描述。
- 接入代码编辑 Agent，根据 `patch_plan.md` 自动生成小步 PR。
- 增加更多语言的 AST 解析，例如 Go、Java、Rust。
- 引入 RAG，把团队编码规范和历史故障报告作为评估依据。
- 对大仓库做分片摘要，支持百万 token 级别的 repo 级理解。

## 许可

MIT License
