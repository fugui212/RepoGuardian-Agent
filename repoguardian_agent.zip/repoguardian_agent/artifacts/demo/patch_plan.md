# Patch Plan

## Recommended PR sequence
1. **P0: Remove security-sensitive patterns before automated patching** — labels: security, p0, agent-ready
2. **P1: Split complex functions into testable units** — labels: maintainability, p1, refactor
3. **P1: Replace broad exception handling with explicit failures** — labels: reliability, p1
4. **P1: Add CI guardrails for agent-generated changes** — labels: ci, testing, p1
5. **P2: Replace ad-hoc debug output with structured logging** — labels: observability, p2

## Execution policy
- Keep each generated PR scoped to one issue and one risk category.
- Run tests after every patch; do not batch unrelated changes.
- Ask the model for a rollback note and migration note for each PR.
- Prefer deterministic mechanical changes before semantic rewrites.

## First patch target
Start with `app.py:6` because it is `high` severity: Possible API key literal.