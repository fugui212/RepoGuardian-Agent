# RepoGuardian Agent Report

## Summary

- Repository: `/mnt/data/repoguardian_agent/sample_repo`
- Files scanned: **4**
- Lines scanned: **124**
- Findings: **15**
- LLM mode: **offline**

## Language footprint

- Python: 114 LOC
- JavaScript: 7 LOC
- Markdown: 3 LOC

## Findings

| Severity | Category | Location | Finding | Recommendation |
| --- | --- | --- | --- | --- |
| high | Security | `app.py:6` | Possible API key literal | Move secrets to environment variables or a secret manager, then rotate the exposed value. |
| high | Security | `app.py:6` | Possible hardcoded credential | Move secrets to environment variables or a secret manager, then rotate the exposed value. |
| high | Security | `app.py:90` | Dangerous dynamic execution via eval | Replace dynamic execution with a constrained parser or a whitelist of allowed operations. |
| high | Security | `app.py:95` | subprocess.run with shell=True | Pass command arguments as a list and avoid shell interpolation. |
| medium | Delivery | `.github/workflows:1` | CI workflow not detected | Add a CI workflow that runs linting and tests for each PR. |
| medium | Reliability | `app.py:15` | Bare except block | Catch explicit exception types, log the failure context and preserve traceback where possible. |
| medium | Maintainability | `app.py:21` | High cyclomatic complexity in calculate_discount | Split the function into smaller units with explicit guard clauses and tests for each branch. |
| medium | Maintainability | `app.py:21` | Long function calculate_discount | Extract parsing, validation and side effects into separate functions before using an AI coding agent. |
| low | Maintainability | `app.py:11` | Open TODO/FIXME/HACK marker | Convert the marker into a tracked issue with owner, priority and acceptance criteria. |
| low | Observability | `app.py:16` | Debug print/log statement | Replace ad-hoc prints with structured logging and appropriate log levels. |
| low | Maintainability | `app.py:89` | Open TODO/FIXME/HACK marker | Convert the marker into a tracked issue with owner, priority and acceptance criteria. |
| low | Observability | `app.py:94` | Debug print/log statement | Replace ad-hoc prints with structured logging and appropriate log levels. |
| low | Observability | `app.py:99` | Debug print/log statement | Replace ad-hoc prints with structured logging and appropriate log levels. |
| low | Maintainability | `web.js:4` | Open TODO/FIXME/HACK marker | Convert the marker into a tracked issue with owner, priority and acceptance criteria. |
| low | Observability | `web.js:5` | Debug print/log statement | Replace ad-hoc prints with structured logging and appropriate log levels. |

## Generated GitHub Issues

### P0: Remove security-sensitive patterns before automated patching

Labels: `security, p0, agent-ready`

## Context
RepoGuardian detected security-sensitive code that should be fixed before broad AI-assisted refactoring.

## Evidence
- `app.py:6` Possible API key literal: sk-demo-hardcoded-key-123456
- `app.py:6` Possible hardcoded credential: API_KEY = "sk-demo-hardcoded-key-123456"
- `app.py:90` Dangerous dynamic execution via eval: eval(...) call
- `app.py:95` subprocess.run with shell=True: shell=True

## Acceptance Criteria
- Hardcoded secrets are moved to environment variables or a secret manager.
- Dynamic execution is replaced with a constrained parser or explicit whitelist.
- Regression tests cover the changed paths.
- The old exposed secret is rotated if it ever represented a real credential.

### P1: Split complex functions into testable units

Labels: `maintainability, p1, refactor`

## Context
Large or branch-heavy functions reduce the reliability of code-generation agents because edits touch too much behavior at once.

## Candidates
- `app.py:21` High cyclomatic complexity in calculate_discount
- `app.py:21` Long function calculate_discount
- `app.py:11` Open TODO/FIXME/HACK marker
- `app.py:89` Open TODO/FIXME/HACK marker
- `web.js:4` Open TODO/FIXME/HACK marker

## Acceptance Criteria
- Extract pure validation/parsing helpers.
- Keep each PR under a small reviewable scope.
- Add unit tests around each extracted helper.

### P1: Replace broad exception handling with explicit failures

Labels: `reliability, p1`

## Context
Broad exception handling hides failures and makes agent-generated patches harder to validate.

## Evidence
- `app.py:15` Bare except block

## Acceptance Criteria
- Catch explicit exception classes only.
- Log structured failure context.
- Preserve traceback or re-raise when the operation cannot recover safely.

### P1: Add CI guardrails for agent-generated changes

Labels: `ci, testing, p1`

## Context
Automated refactors need a safety net. CI should run before generated changes are merged.

## Evidence
- `.github/workflows:1` CI workflow not detected

## Acceptance Criteria
- Add a workflow that runs tests on pull_request.
- Include smoke tests for the critical path.
- Make the workflow status required before merge.

### P2: Replace ad-hoc debug output with structured logging

Labels: `observability, p2`

## Context
Debug prints are noisy in production and make automated evaluation harder.

## Evidence
- `app.py:16` Debug print/log statement
- `app.py:94` Debug print/log statement
- `app.py:99` Debug print/log statement
- `web.js:5` Debug print/log statement

## Acceptance Criteria
- Replace prints with logger calls.
- Use meaningful log levels.
- Avoid logging secrets or personally identifiable information.


## Agent Trace

### RiskAnalystAgent

Mode: `deterministic-fallback`  
Duration: `0 ms`  
Estimated tokens: `538`

Risk posture: action required before trusting autonomous patch generation.
The scan covered 4 files and 124 lines, with 15 findings.
Severity distribution: {"high": 4, "medium": 4, "low": 7}.
Dominant risk categories: Maintainability(5), Security(4), Observability(4), Delivery(1), Reliability(1).
Primary concern: security-sensitive findings exist, especially app.py:6 Possible API key literal; app.py:6 Possible hardcoded credential; app.py:90 Dangerous dynamic execution via eval.
Secondary concern: maintainability and delivery guardrails should be improved before broad refactors.
Recommended strategy: fix secrets/dynamic execution first, then split long functions, then add CI and regression tests.

### PatchPlannerAgent

Mode: `deterministic-fallback`  
Duration: `0 ms`  
Estimated tokens: `770`

# Patch Plan

## Recommended PR sequence
1. **P0: Remove security-sensitive patterns before automated patching** — labels: security, p0, agent-ready
2. **P1: Split complex functions into testable units** — labels: maintainability, p1, refactor
3. **P1: Replace broad exception handling with explicit failures** — labels: reliability, p1
4. **P1: Add CI guardrails for agent-generated changes** — labels: ci, testing, p1
5. **P2: Replace ad-hoc debug output with structured logging** — labels: observability, p2

## Execution policy
- Keep each generated PR scoped to one issue and one risk category.
- Run tests after every patch; do not batch unrelated changes.
- Ask the model for a rollback note and migration note for each PR.
- Prefer deterministic mechanical changes before semantic rewrites.

## First patch target
Start with `app.py:6` because it is `high` severity: Possible API key literal.

### TestDesignerAgent

Mode: `deterministic-fallback`  
Duration: `0 ms`  
Estimated tokens: `720`

Testing strategy for agent-generated patches:
1. Add smoke tests for the main application path before changing behavior.
2. Add focused unit tests around any extracted functions.
3. Add security regression tests for removed dynamic execution or secret loading paths.
4. Add CI to run tests on every pull_request.
Security-specific test: assert that credentials are read from environment variables and dangerous inputs are rejected.
Reliability-specific test: simulate expected exceptions and verify the error path is observable.
