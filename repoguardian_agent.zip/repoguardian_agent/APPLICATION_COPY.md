# 申请表填写文案草稿

## 04 请描述你使用 Agent 或 AI 驱动构建的具体成果

我构建了一个名为 RepoGuardian Agent 的 AI 代码库巡检与重构规划 Agent，用来解决团队接入 AI 编程时最常见的痛点：模型可以写代码，但在面对真实仓库时缺少全局上下文，不知道哪些技术债、安全风险和测试缺口应该优先处理。该项目会先扫描本地仓库，提取文件结构、语言占比、函数数量、复杂度、TODO/FIXME、硬编码密钥、危险 eval/exec、裸 except、缺失 CI 等信号，再把结果交给 Risk Analyst Agent、Patch Planner Agent、Test Designer Agent 三个角色协作处理。Risk Agent 负责压缩代码库上下文并排序风险；Planner Agent 把发现拆成 GitHub Issue、PR 顺序、验收标准和回滚边界；Test Agent 为每个改动生成回归测试策略。最终系统会输出 report.md、issues.json、patch_plan.md、agent_trace.jsonl 和一个可直接用 GitHub Pages 展示的 dashboard。

我这次提交的版本包含完整可运行代码、sample_repo 演示仓库、终端运行日志和 Agent 工作流截图。离线模式无需 API Key 即可复现实验；配置 OpenAI/MiMo 兼容接口后，可把风险分析、任务拆分和测试设计替换为真实 GPT/MiMo 推理。这个项目的核心价值不是单次生成一段代码，而是把“代码库理解 → 风险判断 → 小步 PR 规划 → 测试护栏”的流程标准化，适合后续扩展到 GitHub Issue 自动创建、自动 PR 草拟和百万 token 级大仓库分片理解。Token plan 额度会主要用于真实仓库的多轮摘要、跨文件依赖推理、PR 计划生成和回归测试设计。

## 05 可上传材料说明

1. 上传 `screenshots/terminal_run.png`：终端运行日志截图。
2. 上传 `screenshots/workflow_dashboard.png`：Agent workflow/dashboard 截图。
3. 上传 GitHub 链接：把压缩包解压后推到你的 GitHub，填写真实仓库地址，例如 `https://github.com/<你的用户名>/repoguardian_agent`。如果启用 GitHub Pages，可再填写 `https://<你的用户名>.github.io/repoguardian_agent/`。
