from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any

from .agents import AgentStep
from .scanner import SEVERITY_SCORE, ScanResult


def _severity_badge(severity: str) -> str:
    return f'<span class="badge badge-{html.escape(severity)}">{html.escape(severity)}</span>'


def render_markdown(scan: ScanResult, pipeline: dict[str, Any], out_dir: str | Path) -> Path:
    out_path = Path(out_dir)
    metrics = scan.metrics
    lines: list[str] = [
        "# RepoGuardian Agent Report",
        "",
        "## Summary",
        "",
        f"- Repository: `{scan.root}`",
        f"- Files scanned: **{metrics.get('file_count', 0)}**",
        f"- Lines scanned: **{metrics.get('line_count', 0)}**",
        f"- Findings: **{metrics.get('finding_count', 0)}**",
        f"- LLM mode: **{pipeline.get('llm_mode', 'offline')}**",
        "",
        "## Language footprint",
        "",
    ]
    for lang, count in metrics.get("language_lines", {}).items():
        lines.append(f"- {lang}: {count} LOC")

    lines.extend(["", "## Findings", ""])
    if scan.findings:
        lines.extend(["| Severity | Category | Location | Finding | Recommendation |", "| --- | --- | --- | --- | --- |"])
        for finding in scan.findings:
            lines.append(
                f"| {finding.severity} | {finding.category} | `{finding.file}:{finding.line}` | {finding.title} | {finding.recommendation} |"
            )
    else:
        lines.append("No findings detected.")

    lines.extend(["", "## Generated GitHub Issues", ""])
    for issue in pipeline.get("issues", []):
        lines.append(f"### {issue['title']}")
        lines.append("")
        lines.append(f"Labels: `{', '.join(issue['labels'])}`")
        lines.append("")
        lines.append(issue["body"])
        lines.append("")

    lines.extend(["", "## Agent Trace", ""])
    for step in pipeline.get("steps", []):
        lines.append(f"### {step.agent}")
        lines.append("")
        lines.append(f"Mode: `{step.mode}`  ")
        lines.append(f"Duration: `{step.duration_ms} ms`  ")
        lines.append(f"Estimated tokens: `{step.prompt_tokens_estimate + step.completion_tokens_estimate}`")
        lines.append("")
        lines.append(step.output)
        lines.append("")

    report = out_path / "report.md"
    report.write_text("\n".join(lines), encoding="utf-8")
    return report


def _format_count_map(data: dict[str, int]) -> str:
    if not data:
        return "None"
    return ", ".join(f"{html.escape(str(k))}: {v}" for k, v in data.items())


def render_html(scan: ScanResult, pipeline: dict[str, Any], out_dir: str | Path) -> Path:
    out_path = Path(out_dir)
    metrics = scan.metrics
    findings_rows = []
    for finding in scan.findings[:80]:
        findings_rows.append(
            "<tr>"
            f"<td>{_severity_badge(finding.severity)}</td>"
            f"<td>{html.escape(finding.category)}</td>"
            f"<td><code>{html.escape(finding.file)}:{finding.line}</code></td>"
            f"<td><strong>{html.escape(finding.title)}</strong><br><small>{html.escape(finding.evidence)}</small></td>"
            f"<td>{html.escape(finding.recommendation)}</td>"
            "</tr>"
        )

    issues_cards = []
    for issue in pipeline.get("issues", []):
        labels = " ".join(f"<span class='pill'>{html.escape(label)}</span>" for label in issue.get("labels", []))
        body = html.escape(issue.get("body", ""))
        issues_cards.append(
            f"<article class='issue'><h3>{html.escape(issue['title'])}</h3><div>{labels}</div><pre>{body}</pre></article>"
        )

    steps_html = []
    for index, step in enumerate(pipeline.get("steps", []), start=1):
        assert isinstance(step, AgentStep)
        total_tokens = step.prompt_tokens_estimate + step.completion_tokens_estimate
        steps_html.append(
            "<div class='step'>"
            f"<div class='step-num'>{index}</div>"
            f"<div><h3>{html.escape(step.agent)}</h3>"
            f"<p><span class='pill'>{html.escape(step.mode)}</span> <span class='pill'>{step.duration_ms} ms</span> <span class='pill'>~{total_tokens} tokens</span></p>"
            f"<p>{html.escape(step.output[:520])}{'...' if len(step.output) > 520 else ''}</p>"
            "</div></div>"
        )

    language_bars = []
    language_lines = metrics.get("language_lines", {})
    max_lines = max(language_lines.values(), default=1)
    for lang, count in language_lines.items():
        pct = int(count / max_lines * 100) if max_lines else 0
        language_bars.append(
            f"<div class='bar-row'><span>{html.escape(lang)}</span><div class='bar'><i style='width:{pct}%'></i></div><b>{count}</b></div>"
        )

    html_doc = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>RepoGuardian Agent Dashboard</title>
  <style>
    :root {{ --bg:#0d1117; --panel:#161b22; --muted:#8b949e; --text:#f0f6fc; --line:#30363d; --accent:#7c3aed; --accent2:#22c55e; --danger:#ef4444; --warn:#f59e0b; --low:#38bdf8; }}
    * {{ box-sizing:border-box; }}
    body {{ margin:0; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Noto Sans",Arial,sans-serif; background:linear-gradient(160deg,#0d1117 0%,#111827 100%); color:var(--text); }}
    header {{ padding:48px 56px 28px; border-bottom:1px solid var(--line); background:radial-gradient(circle at top right,rgba(124,58,237,.34),transparent 34%); }}
    header h1 {{ margin:0 0 12px; font-size:44px; letter-spacing:-.04em; }}
    header p {{ margin:0; color:var(--muted); font-size:18px; max-width:900px; line-height:1.55; }}
    main {{ padding:32px 56px 64px; max-width:1500px; margin:auto; }}
    .grid {{ display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:18px; margin-bottom:28px; }}
    .card,.issue,.step,.table-wrap,.flow {{ background:rgba(22,27,34,.82); border:1px solid var(--line); border-radius:18px; box-shadow:0 16px 40px rgba(0,0,0,.22); }}
    .card {{ padding:22px; }}
    .card small {{ color:var(--muted); text-transform:uppercase; letter-spacing:.1em; }}
    .card strong {{ display:block; font-size:34px; margin-top:8px; }}
    h2 {{ margin:34px 0 18px; font-size:26px; letter-spacing:-.02em; }}
    .flow {{ padding:24px; margin:18px 0 26px; }}
    .flowline {{ display:flex; align-items:center; gap:12px; flex-wrap:wrap; }}
    .node {{ padding:14px 16px; background:#0f172a; border:1px solid #334155; border-radius:14px; font-weight:700; }}
    .arrow {{ color:var(--muted); font-size:24px; }}
    .two-col {{ display:grid; grid-template-columns:1.1fr .9fr; gap:20px; }}
    .bar-row {{ display:grid; grid-template-columns:120px 1fr 60px; gap:12px; align-items:center; margin:12px 0; color:#c9d1d9; }}
    .bar {{ height:12px; background:#0f172a; border-radius:99px; overflow:hidden; border:1px solid #263244; }}
    .bar i {{ display:block; height:100%; background:linear-gradient(90deg,var(--accent),#06b6d4); }}
    table {{ width:100%; border-collapse:collapse; }}
    th,td {{ padding:13px 14px; border-bottom:1px solid var(--line); text-align:left; vertical-align:top; }}
    th {{ color:#c9d1d9; background:#0f172a; position:sticky; top:0; }}
    code,pre {{ font-family:"SFMono-Regular",Consolas,"Liberation Mono",monospace; }}
    pre {{ white-space:pre-wrap; color:#c9d1d9; background:#0d1117; border:1px solid var(--line); border-radius:12px; padding:12px; max-height:280px; overflow:auto; }}
    small,.muted {{ color:var(--muted); }}
    .badge,.pill {{ display:inline-block; border-radius:999px; padding:4px 10px; font-size:12px; font-weight:700; border:1px solid transparent; }}
    .pill {{ color:#c9d1d9; border-color:#334155; background:#0f172a; margin:3px 4px 3px 0; }}
    .badge-high {{ background:rgba(239,68,68,.16); color:#fecaca; border-color:rgba(239,68,68,.4); }}
    .badge-medium {{ background:rgba(245,158,11,.16); color:#fde68a; border-color:rgba(245,158,11,.38); }}
    .badge-low {{ background:rgba(56,189,248,.14); color:#bae6fd; border-color:rgba(56,189,248,.36); }}
    .step {{ display:flex; gap:16px; padding:18px; margin-bottom:14px; }}
    .step h3 {{ margin:0 0 6px; }}
    .step p {{ margin:8px 0; color:#c9d1d9; line-height:1.55; }}
    .step-num {{ flex:0 0 38px; height:38px; border-radius:50%; background:linear-gradient(135deg,var(--accent),#06b6d4); display:flex; align-items:center; justify-content:center; font-weight:800; }}
    .issues {{ display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:16px; }}
    .issue {{ padding:18px; }}
    .issue h3 {{ margin:0 0 10px; }}
    .table-wrap {{ overflow:auto; max-height:580px; }}
    footer {{ margin-top:38px; color:var(--muted); font-size:13px; }}
    @media (max-width:900px) {{ header,main {{ padding-left:22px; padding-right:22px; }} .grid,.two-col,.issues {{ grid-template-columns:1fr; }} }}
  </style>
</head>
<body>
<header>
  <h1>RepoGuardian Agent</h1>
  <p>AI codebase health scanner and refactor planning agent. This dashboard is generated from a real local CLI run and is ready to publish with GitHub Pages.</p>
</header>
<main>
  <section class="grid">
    <div class="card"><small>Files</small><strong>{metrics.get('file_count', 0)}</strong></div>
    <div class="card"><small>Lines</small><strong>{metrics.get('line_count', 0)}</strong></div>
    <div class="card"><small>Findings</small><strong>{metrics.get('finding_count', 0)}</strong></div>
    <div class="card"><small>LLM Mode</small><strong>{html.escape(pipeline.get('llm_mode', 'offline'))}</strong></div>
  </section>

  <section class="flow">
    <h2>Agent Workflow</h2>
    <div class="flowline">
      <div class="node">Repository Scanner</div><div class="arrow">→</div>
      <div class="node">Risk Analyst Agent</div><div class="arrow">→</div>
      <div class="node">Patch Planner Agent</div><div class="arrow">→</div>
      <div class="node">Test Designer Agent</div><div class="arrow">→</div>
      <div class="node">Dashboard + Issues</div>
    </div>
  </section>

  <section class="two-col">
    <div>
      <h2>Language Footprint</h2>
      <div class="card">{''.join(language_bars)}</div>
    </div>
    <div>
      <h2>Risk Distribution</h2>
      <div class="card">
        <p><strong>Severity:</strong> {_format_count_map(metrics.get('severity_counts', {}))}</p>
        <p><strong>Category:</strong> {_format_count_map(metrics.get('category_counts', {}))}</p>
        <p class="muted">Repository: <code>{html.escape(scan.root)}</code></p>
      </div>
    </div>
  </section>

  <h2>Agent Trace</h2>
  {''.join(steps_html)}

  <h2>Generated GitHub Issues</h2>
  <section class="issues">{''.join(issues_cards)}</section>

  <h2>Findings</h2>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Severity</th><th>Category</th><th>Location</th><th>Evidence</th><th>Recommendation</th></tr></thead>
      <tbody>{''.join(findings_rows) or '<tr><td colspan="5">No findings detected.</td></tr>'}</tbody>
    </table>
  </div>

  <footer>
    Generated by RepoGuardian Agent. Files: report.md, issues.json, patch_plan.md, scan.json, agent_trace.jsonl.
  </footer>
</main>
</body>
</html>"""
    index = out_path / "index.html"
    index.write_text(html_doc, encoding="utf-8")
    return index


def write_json_artifacts(scan: ScanResult, pipeline: dict[str, Any], out_dir: str | Path) -> None:
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    (out_path / "scan.json").write_text(scan.to_json(), encoding="utf-8")
    manifest = {
        "repository": scan.root,
        "metrics": scan.metrics,
        "llm_mode": pipeline.get("llm_mode", "offline"),
        "artifacts": ["index.html", "report.md", "issues.json", "patch_plan.md", "scan.json", "agent_trace.jsonl"],
    }
    (out_path / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
