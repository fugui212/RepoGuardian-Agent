from __future__ import annotations

import argparse
import http.server
import socketserver
from pathlib import Path


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format: str, *args) -> None:  # noqa: A003 - inherited API
        print("[RepoGuardian demo] " + format % args)


def main() -> int:
    parser = argparse.ArgumentParser(description="Serve a RepoGuardian generated dashboard")
    parser.add_argument("directory", nargs="?", default="artifacts/demo", help="directory containing index.html")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()

    directory = Path(args.directory).resolve()
    if not (directory / "index.html").exists():
        raise SystemExit(f"index.html not found in {directory}. Run the scan command first.")

    handler = lambda *h_args, **h_kwargs: QuietHandler(*h_args, directory=str(directory), **h_kwargs)
    with socketserver.TCPServer(("", args.port), handler) as httpd:
        print(f"Serving RepoGuardian dashboard: http://localhost:{args.port}")
        print(f"Directory: {directory}")
        httpd.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
