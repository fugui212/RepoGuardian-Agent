from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

from .agents import run_agent_pipeline
from .render import render_html, render_markdown, write_json_artifacts
from .scanner import scan_repository


def _print_summary(out_dir: Path, metrics: dict, llm_mode: str) -> None:
    print("\nRepoGuardian Agent finished")
    print("=" * 34)
    print(f"Files scanned     : {metrics.get('file_count', 0)}")
    print(f"Lines scanned     : {metrics.get('line_count', 0)}")
    print(f"Findings          : {metrics.get('finding_count', 0)}")
    print(f"Severity counts   : {metrics.get('severity_counts', {})}")
    print(f"Category counts   : {metrics.get('category_counts', {})}")
    print(f"LLM mode          : {llm_mode}")
    print("\nArtifacts")
    print(f"- Dashboard       : {out_dir / 'index.html'}")
    print(f"- Report          : {out_dir / 'report.md'}")
    print(f"- GitHub issues   : {out_dir / 'issues.json'}")
    print(f"- Patch plan      : {out_dir / 'patch_plan.md'}")
    print(f"- Agent trace     : {out_dir / 'agent_trace.jsonl'}")


def scan_command(args: argparse.Namespace) -> int:
    target = Path(args.target)
    out_dir = Path(args.out)
    if out_dir.exists() and args.clean:
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    print("RepoGuardian Agent")
    print("Scanning repository:", target)
    print("Output directory   :", out_dir)
    print("Offline mode       :", bool(args.offline))

    scan = scan_repository(target)
    pipeline = run_agent_pipeline(scan, out_dir, offline=args.offline)
    write_json_artifacts(scan, pipeline, out_dir)
    render_markdown(scan, pipeline, out_dir)
    render_html(scan, pipeline, out_dir)
    _print_summary(out_dir, scan.metrics, pipeline.get("llm_mode", "offline"))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="RepoGuardian Agent: AI codebase health and refactor planning agent")
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan = subparsers.add_parser("scan", help="scan a local repository and generate agent artifacts")
    scan.add_argument("target", help="path to the repository to scan")
    scan.add_argument("--out", default="artifacts/demo", help="output directory for reports and dashboard")
    scan.add_argument("--offline", action="store_true", help="force deterministic local agent mode")
    scan.add_argument("--clean", action="store_true", help="remove output directory before running")
    scan.set_defaults(func=scan_command)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except Exception as exc:  # pragma: no cover - CLI boundary
        print(f"RepoGuardian failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
