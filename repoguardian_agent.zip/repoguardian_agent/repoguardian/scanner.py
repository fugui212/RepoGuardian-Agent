from __future__ import annotations

import ast
import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable

IGNORE_DIRS = {
    ".git",
    ".hg",
    ".svn",
    "node_modules",
    "dist",
    "build",
    "target",
    ".venv",
    "venv",
    "env",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "artifacts",
}

SOURCE_EXTENSIONS = {
    ".py",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".go",
    ".java",
    ".rs",
    ".md",
    ".yaml",
    ".yml",
    ".json",
}

SECRET_RE = re.compile(
    r"(?i)(api[_-]?key|secret|token|password|private[_-]?key)\s*[:=]\s*['\"][A-Za-z0-9_\-./]{6,}['\"]"
)
OPENAI_STYLE_KEY_RE = re.compile(r"sk-[A-Za-z0-9_\-]{8,}")
TODO_RE = re.compile(r"\b(TODO|FIXME|HACK)\b", re.IGNORECASE)
DEBUG_PRINT_RE = re.compile(r"\b(print|console\.log)\s*\(")

SEVERITY_SCORE = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}


@dataclass
class Finding:
    id: str
    severity: str
    category: str
    file: str
    line: int
    title: str
    evidence: str
    recommendation: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class FileStat:
    path: str
    language: str
    lines: int
    functions: int = 0
    classes: int = 0
    complexity: int = 0
    sha1: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ScanResult:
    root: str
    files: list[FileStat] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)
    metrics: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "root": self.root,
            "files": [item.to_dict() for item in self.files],
            "findings": [item.to_dict() for item in self.findings],
            "metrics": self.metrics,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


def language_for(path: Path) -> str:
    mapping = {
        ".py": "Python",
        ".js": "JavaScript",
        ".jsx": "JavaScript",
        ".ts": "TypeScript",
        ".tsx": "TypeScript",
        ".go": "Go",
        ".java": "Java",
        ".rs": "Rust",
        ".md": "Markdown",
        ".yaml": "YAML",
        ".yml": "YAML",
        ".json": "JSON",
    }
    return mapping.get(path.suffix.lower(), path.suffix.lower().lstrip(".").title() or "Text")


def iter_source_files(root: Path, max_file_bytes: int = 200_000) -> Iterable[Path]:
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if any(part in IGNORE_DIRS for part in path.relative_to(root).parts):
            continue
        if path.suffix.lower() not in SOURCE_EXTENSIONS:
            continue
        try:
            if path.stat().st_size > max_file_bytes:
                continue
        except OSError:
            continue
        yield path


def _finding_id(path: str, line: int, category: str, title: str) -> str:
    raw = f"{path}:{line}:{category}:{title}".encode("utf-8")
    return hashlib.sha1(raw).hexdigest()[:10]


def _add_finding(
    findings: list[Finding],
    *,
    severity: str,
    category: str,
    file: str,
    line: int,
    title: str,
    evidence: str,
    recommendation: str,
) -> None:
    findings.append(
        Finding(
            id=_finding_id(file, line, category, title),
            severity=severity,
            category=category,
            file=file,
            line=line,
            title=title,
            evidence=evidence.strip()[:220],
            recommendation=recommendation,
        )
    )


def _line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def _safe_read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def _analyze_text(rel: str, text: str, findings: list[Finding]) -> None:
    for match in TODO_RE.finditer(text):
        line = _line_number(text, match.start())
        snippet = text.splitlines()[line - 1] if line - 1 < len(text.splitlines()) else match.group(0)
        _add_finding(
            findings,
            severity="low",
            category="Maintainability",
            file=rel,
            line=line,
            title="Open TODO/FIXME/HACK marker",
            evidence=snippet,
            recommendation="Convert the marker into a tracked issue with owner, priority and acceptance criteria.",
        )

    for regex, title in [
        (SECRET_RE, "Possible hardcoded credential"),
        (OPENAI_STYLE_KEY_RE, "Possible API key literal"),
    ]:
        for match in regex.finditer(text):
            line = _line_number(text, match.start())
            _add_finding(
                findings,
                severity="high",
                category="Security",
                file=rel,
                line=line,
                title=title,
                evidence=match.group(0),
                recommendation="Move secrets to environment variables or a secret manager, then rotate the exposed value.",
            )

    for match in DEBUG_PRINT_RE.finditer(text):
        line = _line_number(text, match.start())
        _add_finding(
            findings,
            severity="low",
            category="Observability",
            file=rel,
            line=line,
            title="Debug print/log statement",
            evidence=text.splitlines()[line - 1].strip() if line - 1 < len(text.splitlines()) else match.group(0),
            recommendation="Replace ad-hoc prints with structured logging and appropriate log levels.",
        )


def _complexity_for_node(node: ast.AST) -> int:
    score = 1
    complexity_nodes = (
        ast.If,
        ast.For,
        ast.AsyncFor,
        ast.While,
        ast.Try,
        ast.ExceptHandler,
        ast.With,
        ast.AsyncWith,
        ast.BoolOp,
        ast.IfExp,
        ast.Match,
    )
    for child in ast.walk(node):
        if isinstance(child, complexity_nodes):
            score += 1
        elif isinstance(child, ast.comprehension):
            score += 1
    return score


def _analyze_python(rel: str, text: str, findings: list[Finding]) -> tuple[int, int, int]:
    try:
        tree = ast.parse(text)
    except SyntaxError as exc:
        _add_finding(
            findings,
            severity="medium",
            category="Correctness",
            file=rel,
            line=exc.lineno or 1,
            title="Python syntax error",
            evidence=str(exc),
            recommendation="Fix syntax errors before running automated refactors or tests.",
        )
        return 0, 0, 0

    functions = 0
    classes = 0
    total_complexity = 0
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            functions += 1
            complexity = _complexity_for_node(node)
            total_complexity += complexity
            length = (getattr(node, "end_lineno", node.lineno) or node.lineno) - node.lineno + 1
            if complexity >= 10:
                _add_finding(
                    findings,
                    severity="medium",
                    category="Maintainability",
                    file=rel,
                    line=node.lineno,
                    title=f"High cyclomatic complexity in {node.name}",
                    evidence=f"complexity={complexity}",
                    recommendation="Split the function into smaller units with explicit guard clauses and tests for each branch.",
                )
            if length >= 45:
                _add_finding(
                    findings,
                    severity="medium",
                    category="Maintainability",
                    file=rel,
                    line=node.lineno,
                    title=f"Long function {node.name}",
                    evidence=f"{length} lines",
                    recommendation="Extract parsing, validation and side effects into separate functions before using an AI coding agent.",
                )
        elif isinstance(node, ast.ClassDef):
            classes += 1
        elif isinstance(node, ast.ExceptHandler) and node.type is None:
            _add_finding(
                findings,
                severity="medium",
                category="Reliability",
                file=rel,
                line=node.lineno,
                title="Bare except block",
                evidence="except:",
                recommendation="Catch explicit exception types, log the failure context and preserve traceback where possible.",
            )
        elif isinstance(node, ast.Call):
            func_name = ""
            if isinstance(node.func, ast.Name):
                func_name = node.func.id
            elif isinstance(node.func, ast.Attribute):
                func_name = node.func.attr
            if func_name in {"eval", "exec"}:
                _add_finding(
                    findings,
                    severity="high",
                    category="Security",
                    file=rel,
                    line=node.lineno,
                    title=f"Dangerous dynamic execution via {func_name}",
                    evidence=f"{func_name}(...) call",
                    recommendation="Replace dynamic execution with a constrained parser or a whitelist of allowed operations.",
                )
            if func_name == "run":
                for keyword in node.keywords:
                    if keyword.arg == "shell" and isinstance(keyword.value, ast.Constant) and keyword.value.value is True:
                        _add_finding(
                            findings,
                            severity="high",
                            category="Security",
                            file=rel,
                            line=node.lineno,
                            title="subprocess.run with shell=True",
                            evidence="shell=True",
                            recommendation="Pass command arguments as a list and avoid shell interpolation.",
                        )
    return functions, classes, total_complexity


def _global_project_findings(root: Path, files: list[FileStat], findings: list[Finding]) -> None:
    rel_paths = {item.path for item in files}
    has_tests = any(Path(path).name.startswith("test_") or "/tests/" in f"/{path}" for path in rel_paths)
    has_readme = any(Path(path).name.lower().startswith("readme") for path in rel_paths)
    has_ci = (root / ".github" / "workflows").exists()

    if not has_tests:
        _add_finding(
            findings,
            severity="medium",
            category="Testing",
            file=".",
            line=1,
            title="No test files detected",
            evidence="No tests/ directory or test_*.py file was found in scanned sources.",
            recommendation="Add smoke tests before allowing an Agent to generate automated patches.",
        )

    if not has_readme:
        _add_finding(
            findings,
            severity="low",
            category="Documentation",
            file=".",
            line=1,
            title="README not detected",
            evidence="No README-style file was found.",
            recommendation="Add a README with setup commands, architecture and safety notes.",
        )

    if not has_ci:
        _add_finding(
            findings,
            severity="medium",
            category="Delivery",
            file=".github/workflows",
            line=1,
            title="CI workflow not detected",
            evidence=".github/workflows is missing.",
            recommendation="Add a CI workflow that runs linting and tests for each PR.",
        )


def scan_repository(root: str | Path, max_file_bytes: int = 200_000) -> ScanResult:
    root_path = Path(root).expanduser().resolve()
    if not root_path.exists():
        raise FileNotFoundError(f"Repository path does not exist: {root_path}")
    if not root_path.is_dir():
        raise NotADirectoryError(f"Repository path is not a directory: {root_path}")

    files: list[FileStat] = []
    findings: list[Finding] = []
    languages: dict[str, int] = {}

    for path in iter_source_files(root_path, max_file_bytes=max_file_bytes):
        rel = path.relative_to(root_path).as_posix()
        text = _safe_read(path)
        lines = len(text.splitlines())
        sha1 = hashlib.sha1(text.encode("utf-8", errors="ignore")).hexdigest()[:12]
        language = language_for(path)
        languages[language] = languages.get(language, 0) + lines

        functions = classes = complexity = 0
        _analyze_text(rel, text, findings)
        if path.suffix.lower() == ".py":
            functions, classes, complexity = _analyze_python(rel, text, findings)

        files.append(
            FileStat(
                path=rel,
                language=language,
                lines=lines,
                functions=functions,
                classes=classes,
                complexity=complexity,
                sha1=sha1,
            )
        )

    _global_project_findings(root_path, files, findings)

    findings.sort(key=lambda f: (-SEVERITY_SCORE.get(f.severity, 0), f.file, f.line, f.title))
    severity_counts: dict[str, int] = {}
    category_counts: dict[str, int] = {}
    for item in findings:
        severity_counts[item.severity] = severity_counts.get(item.severity, 0) + 1
        category_counts[item.category] = category_counts.get(item.category, 0) + 1

    metrics = {
        "file_count": len(files),
        "line_count": sum(item.lines for item in files),
        "function_count": sum(item.functions for item in files),
        "class_count": sum(item.classes for item in files),
        "finding_count": len(findings),
        "severity_counts": severity_counts,
        "category_counts": category_counts,
        "language_lines": dict(sorted(languages.items(), key=lambda kv: (-kv[1], kv[0]))),
    }

    return ScanResult(root=root_path.as_posix(), files=files, findings=findings, metrics=metrics)
