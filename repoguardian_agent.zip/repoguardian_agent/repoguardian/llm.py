from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass


@dataclass
class LLMResponse:
    text: str
    model: str
    prompt_tokens_estimate: int
    completion_tokens_estimate: int


class LLMClient:
    """Tiny OpenAI-compatible Chat Completions client.

    The project intentionally avoids mandatory third-party dependencies. Any gateway
    that implements /chat/completions with an OpenAI-compatible JSON shape can be used.
    """

    def __init__(self, *, offline: bool = False) -> None:
        self.offline = offline or os.getenv("REPOGUARDIAN_OFFLINE", "").lower() in {"1", "true", "yes"}
        self.api_key = os.getenv("OPENAI_API_KEY", "")
        self.base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
        self.model = os.getenv("OPENAI_MODEL", "repo-guardian-configure-a-model")

    @property
    def available(self) -> bool:
        return bool(self.api_key) and not self.offline

    @staticmethod
    def estimate_tokens(text: str) -> int:
        # Simple approximation, enough for local planning and evidence logs.
        return max(1, len(text) // 4)

    def complete(
        self,
        *,
        system: str,
        user: str,
        temperature: float = 0.2,
        max_tokens: int = 900,
    ) -> LLMResponse | None:
        if not self.available:
            return None

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        body = json.dumps(payload).encode("utf-8")
        endpoint = f"{self.base_url}/chat/completions"
        request = urllib.request.Request(
            endpoint,
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                data = json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError) as exc:
            print(f"[RepoGuardian] LLM call failed, falling back to deterministic agent: {exc}")
            return None

        try:
            text = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            return None

        usage = data.get("usage", {}) if isinstance(data, dict) else {}
        return LLMResponse(
            text=text.strip(),
            model=self.model,
            prompt_tokens_estimate=int(usage.get("prompt_tokens") or self.estimate_tokens(system + user)),
            completion_tokens_estimate=int(usage.get("completion_tokens") or self.estimate_tokens(text)),
        )
