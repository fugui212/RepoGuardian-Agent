from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from .llm import LLMClient
from .scanner import SEVERITY_SCORE, Finding, ScanResult


@dataclass
class AgentStep:
    agent: str
    mode: str
    input_summary: str
    output: str
    duration_ms: int
    prompt_tokens_estimate: int
    completion_tokens_estimate: int

    def to_dict(self) -> dict:
        return asdict(self)


def _top_findings(scan: ScanResult, limit: int = 8) -> list[Finding]:
    return sorted(
        scan.findings,
        key=lambda item: (-SEVERITY_SCORE.get(item.severity, 0), item.category, item.file, item.line),
    )[:limit]


def _compact_context(scan: ScanResult) -> str:
    top = _top_findings(scan, limit=10)
    findings_text = "\n".join(
        f"- [{item.severity}] {item.category} {item.file}:{item.line} {item.title} | {item.evidence}"
        for item in top
    )
    return (
        f"Repository: {scan.root}\n"
        f"Metrics: {json.dumps(scan.metrics, ensure_ascii=False)}\n"
        f"Top findings:\n{findings_text}"
    )


def _offline_risk_analysis(scan: ScanResult) -> str:
    metrics = scan.metrics
    severity = metrics.get("severity_counts", {})
    categories = metrics.get("category_counts", {})
    top_categories = ", ".join(f"{name}({count})" for name, count in sorted(categories.items(), key=lambda kv: -kv[1])[:5])
    high_items = [f for f in scan.findings if f.severity in {"critical", "high"}]
    medium_items = [f for f in scan.findings if f.severity == "medium"]

    lines = [
        "Risk posture: action required before trusting autonomous patch generation.",
        f"The scan covered {metrics.get('file_count', 0)} files and {metrics.get('line_count', 0)} lines, with {metrics.get('finding_count', 0)} findings.",
        f"Severity distribution: {json.dumps(severity, ensure_ascii=False)}.",
        f"Dominant risk categories: {top_categories or 'none'}.",
    ]
    if high_items:
        lines.append(
            "Primary concern: security-sensitive findings exist, especially "
            + "; ".join(f"{f.file}:{f.line} {f.title}" for f in high_items[:3])
            + "."
        )
    if medium_items:
        lines.append(
            "Secondary concern: maintainability and delivery guardrails should be improved before broad refactors."
        )
    lines.append("Recommended strategy: fix secrets/dynamic execution first, then split long functions, then add CI and regression tests.")
    return "\n".join(lines)


def _make_issue(title: str, labels: list[str], body_lines: list[str], priority: str) -> dict:
    body = "\n".join(body_lines).strip()
    return {
        "title": title,
        "priority": priority,
        "labels": labels,
        "body": body,
    }


def build_issues(scan: ScanResult) -> list[dict]:
    findings = scan.findings
    by_category: dict[str, list[Finding]] = {}
    for item in findings:
        by_category.setdefault(item.category, []).append(item)

    issues: list[dict] = []
    security = by_category.get("Security", [])
    if security:
        examples = "\n".join(f"- `{f.file}:{f.line}` {f.title}: {f.evidence}" for f in security[:5])
        issues.append(
            _make_issue(
                "P0: Remove security-sensitive patterns before automated patching",
                ["security", "p0", "agent-ready"],
                [
                    "## Context",
                    "RepoGuardian detected security-sensitive code that should be fixed before broad AI-assisted refactoring.",
                    "",
                    "## Evidence",
                    examples,
                    "",
                    "## Acceptance Criteria",
                    "- Hardcoded secrets are moved to environment variables or a secret manager.",
                    "- Dynamic execution is replaced with a constrained parser or explicit whitelist.",
                    "- Regression tests cover the changed paths.",
                    "- The old exposed secret is rotated if it ever represented a real credential.",
                ],
                "P0",
            )
        )

    maintainability = by_category.get("Maintainability", [])
    if maintainability:
        examples = "\n".join(f"- `{f.file}:{f.line}` {f.title}" for f in maintainability[:5])
        issues.append(
            _make_issue(
                "P1: Split complex functions into testable units",
                ["maintainability", "p1", "refactor"],
                [
                    "## Context",
                    "Large or branch-heavy functions reduce the reliability of code-generation agents because edits touch too much behavior at once.",
                    "",
                    "## Candidates",
                    examples,
                    "",
                    "## Acceptance Criteria",
                    "- Extract pure validation/parsing helpers.",
                    "- Keep each PR under a small reviewable scope.",
                    "- Add unit tests around each extracted helper.",
                ],
                "P1",
            )
        )

    reliability = by_category.get("Reliability", [])
    if reliability:
        examples = "\n".join(f"- `{f.file}:{f.line}` {f.title}" for f in reliability[:5])
        issues.append(
            _make_issue(
                "P1: Replace broad exception handling with explicit failures",
                ["reliability", "p1"],
                [
                    "## Context",
                    "Broad exception handling hides failures and makes agent-generated patches harder to validate.",
                    "",
                    "## Evidence",
                    examples,
                    "",
                    "## Acceptance Criteria",
                    "- Catch explicit exception classes only.",
                    "- Log structured failure context.",
                    "- Preserve traceback or re-raise when the operation cannot recover safely.",
                ],
                "P1",
            )
        )

    delivery = by_category.get("Delivery", []) + by_category.get("Testing", [])
    if delivery:
        examples = "\n".join(f"- `{f.file}:{f.line}` {f.title}" for f in delivery[:5])
        issues.append(
            _make_issue(
                "P1: Add CI guardrails for agent-generated changes",
                ["ci", "testing", "p1"],
                [
                    "## Context",
                    "Automated refactors need a safety net. CI should run before generated changes are merged.",
                    "",
                    "## Evidence",
                    examples,
                    "",
                    "## Acceptance Criteria",
                    "- Add a workflow that runs tests on pull_request.",
                    "- Include smoke tests for the critical path.",
                    "- Make the workflow status required before merge.",
                ],
                "P1",
            )
        )

    observability = by_category.get("Observability", [])
    if observability:
        examples = "\n".join(f"- `{f.file}:{f.line}` {f.title}" for f in observability[:5])
        issues.append(
            _make_issue(
                "P2: Replace ad-hoc debug output with structured logging",
                ["observability", "p2"],
                [
                    "## Context",
                    "Debug prints are noisy in production and make automated evaluation harder.",
                    "",
                    "## Evidence",
                    examples,
                    "",
                    "## Acceptance Criteria",
                    "- Replace prints with logger calls.",
                    "- Use meaningful log levels.",
                    "- Avoid logging secrets or personally identifiable information.",
                ],
                "P2",
            )
        )

    if not issues:
        issues.append(
            _make_issue(
                "P2: Keep repository health checks in CI",
                ["maintenance", "p2"],
                [
                    "## Context",
                    "No urgent findings were detected. Keep the scanner in CI to catch regressions.",
                    "",
                    "## Acceptance Criteria",
                    "- Run RepoGuardian on a schedule or before release branches.",
                    "- Save generated reports as CI artifacts.",
                ],
                "P2",
            )
        )
    return issues[:6]


def _offline_patch_plan(scan: ScanResult, issues: list[dict]) -> str:
    lines = [
        "# Patch Plan",
        "",
        "## Recommended PR sequence",
    ]
    for index, issue in enumerate(issues, start=1):
        lines.append(f"{index}. **{issue['title']}** — labels: {', '.join(issue['labels'])}")
    lines.extend(
        [
            "",
            "## Execution policy",
            "- Keep each generated PR scoped to one issue and one risk category.",
            "- Run tests after every patch; do not batch unrelated changes.",
            "- Ask the model for a rollback note and migration note for each PR.",
            "- Prefer deterministic mechanical changes before semantic rewrites.",
        ]
    )
    if scan.findings:
        first = scan.findings[0]
        lines.extend(
            [
                "",
                "## First patch target",
                f"Start with `{first.file}:{first.line}` because it is `{first.severity}` severity: {first.title}.",
            ]
        )
    return "\n".join(lines)


def _offline_test_design(scan: ScanResult) -> str:
    categories = scan.metrics.get("category_counts", {})
    lines = [
        "Testing strategy for agent-generated patches:",
        "1. Add smoke tests for the main application path before changing behavior.",
        "2. Add focused unit tests around any extracted functions.",
        "3. Add security regression tests for removed dynamic execution or secret loading paths.",
        "4. Add CI to run tests on every pull_request.",
    ]
    if categories.get("Security"):
        lines.append("Security-specific test: assert that credentials are read from environment variables and dangerous inputs are rejected.")
    if categories.get("Reliability"):
        lines.append("Reliability-specific test: simulate expected exceptions and verify the error path is observable.")
    return "\n".join(lines)


def _run_step(
    *,
    agent_name: str,
    system: str,
    user: str,
    fallback_text: str,
    llm: LLMClient,
) -> AgentStep:
    started = time.perf_counter()
    response = llm.complete(system=system, user=user) if llm.available else None
    duration_ms = int((time.perf_counter() - started) * 1000)
    if response:
        return AgentStep(
            agent=agent_name,
            mode="llm",
            input_summary=user[:500],
            output=response.text,
            duration_ms=duration_ms,
            prompt_tokens_estimate=response.prompt_tokens_estimate,
            completion_tokens_estimate=response.completion_tokens_estimate,
        )
    return AgentStep(
        agent=agent_name,
        mode="deterministic-fallback",
        input_summary=user[:500],
        output=fallback_text,
        duration_ms=duration_ms,
        prompt_tokens_estimate=LLMClient.estimate_tokens(system + user),
        completion_tokens_estimate=LLMClient.estimate_tokens(fallback_text),
    )


def run_agent_pipeline(scan: ScanResult, out_dir: str | Path, *, offline: bool = False) -> dict:
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    llm = LLMClient(offline=offline)
    context = _compact_context(scan)

    risk_step = _run_step(
        agent_name="RiskAnalystAgent",
        system="You are a senior staff engineer. Produce a concise risk analysis for an AI-assisted codebase refactor.",
        user=context,
        fallback_text=_offline_risk_analysis(scan),
        llm=llm,
    )

    issues = build_issues(scan)
    patch_fallback = _offline_patch_plan(scan, issues)
    patch_step = _run_step(
        agent_name="PatchPlannerAgent",
        system="You turn code review findings into a safe PR sequence with GitHub issues, acceptance criteria and rollback notes.",
        user=context + "\n\nRisk analysis:\n" + risk_step.output,
        fallback_text=patch_fallback,
        llm=llm,
    )

    test_step = _run_step(
        agent_name="TestDesignerAgent",
        system="You design regression tests for AI-generated code changes. Be concrete and safety-oriented.",
        user=context + "\n\nPatch plan:\n" + patch_step.output,
        fallback_text=_offline_test_design(scan),
        llm=llm,
    )

    steps = [risk_step, patch_step, test_step]
    trace_file = out_path / "agent_trace.jsonl"
    with trace_file.open("w", encoding="utf-8") as fh:
        for step in steps:
            fh.write(json.dumps(step.to_dict(), ensure_ascii=False) + "\n")

    issues_file = out_path / "issues.json"
    issues_file.write_text(json.dumps(issues, ensure_ascii=False, indent=2), encoding="utf-8")

    patch_plan = patch_step.output if patch_step.output.lstrip().startswith("#") else patch_fallback
    (out_path / "patch_plan.md").write_text(patch_plan, encoding="utf-8")

    return {
        "steps": steps,
        "issues": issues,
        "patch_plan": patch_plan,
        "llm_mode": "online" if llm.available else "offline",
    }
