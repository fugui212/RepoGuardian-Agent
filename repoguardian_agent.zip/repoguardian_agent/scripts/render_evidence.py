from __future__ import annotations

import json
import textwrap
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "screenshots"
OUT.mkdir(exist_ok=True)

FONT_REGULAR = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
FONT_BOLD = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
FONT_MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
FONT_MONO_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"


def f(size: int, bold: bool = False, mono: bool = False) -> ImageFont.FreeTypeFont:
    path = FONT_MONO_BOLD if mono and bold else FONT_MONO if mono else FONT_BOLD if bold else FONT_REGULAR
    return ImageFont.truetype(path, size)


def draw_wrapped(draw: ImageDraw.ImageDraw, text: str, xy: tuple[int, int], font, fill, width: int, line_gap: int = 6) -> int:
    x, y = xy
    # Approximate wrap by pixel length, preserving explicit line breaks.
    for para in text.split("\n"):
        if not para:
            y += font.size + line_gap
            continue
        current = ""
        for char in para:
            candidate = current + char
            bbox = draw.textbbox((x, y), candidate, font=font)
            if bbox[2] - bbox[0] > width and current:
                draw.text((x, y), current, font=font, fill=fill)
                y += font.size + line_gap
                current = char
            else:
                current = candidate
        if current:
            draw.text((x, y), current, font=font, fill=fill)
            y += font.size + line_gap
    return y


def card(draw, xy, size, title, value, subtitle=""):
    x, y = xy
    w, h = size
    draw.rounded_rectangle([x, y, x + w, y + h], radius=22, fill=(22, 27, 34), outline=(48, 54, 61), width=2)
    draw.text((x + 22, y + 18), title.upper(), font=f(18, bold=True), fill=(139, 148, 158))
    draw.text((x + 22, y + 54), str(value), font=f(42, bold=True), fill=(240, 246, 252))
    if subtitle:
        draw.text((x + 22, y + 108), subtitle, font=f(17), fill=(139, 148, 158))


def render_terminal():
    log_path = ROOT / "evidence" / "terminal_run.log"
    text = log_path.read_text(encoding="utf-8")
    width, height = 1500, 960
    img = Image.new("RGB", (width, height), (13, 17, 23))
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle([40, 40, width - 40, height - 40], radius=18, fill=(6, 10, 16), outline=(48, 54, 61), width=2)
    draw.rounded_rectangle([40, 40, width - 40, 92], radius=18, fill=(22, 27, 34))
    # cover lower rounded spill so title bar looks clean
    draw.rectangle([40, 66, width - 40, 92], fill=(22, 27, 34))
    for i, color in enumerate([(248, 81, 73), (210, 153, 34), (63, 185, 80)]):
        draw.ellipse([68 + i * 30, 58, 86 + i * 30, 76], fill=color)
    draw.text((165, 55), "terminal — python -m repoguardian scan sample_repo --offline", font=f(18, mono=True), fill=(201, 209, 217))

    y = 122
    for line in text.splitlines():
        fill = (201, 209, 217)
        if "RepoGuardian Agent finished" in line:
            fill = (126, 231, 135)
        elif "Findings" in line or "Severity" in line or "LLM mode" in line:
            fill = (121, 192, 255)
        elif line.startswith("-"):
            fill = (210, 168, 255)
        wrapped = textwrap.wrap(line, width=112, subsequent_indent="    ") or [""]
        for chunk in wrapped:
            if y > height - 115:
                break
            draw.text((72, y), chunk, font=f(20, mono=True), fill=fill)
            y += 31
    draw.text((72, height - 82), "Evidence generated from an actual CLI run. Full log: evidence/terminal_run.log", font=f(18), fill=(139, 148, 158))
    img.save(OUT / "terminal_run.png")


def render_dashboard():
    scan = json.loads((ROOT / "artifacts" / "demo" / "scan.json").read_text(encoding="utf-8"))
    issues = json.loads((ROOT / "artifacts" / "demo" / "issues.json").read_text(encoding="utf-8"))
    trace = []
    for line in (ROOT / "artifacts" / "demo" / "agent_trace.jsonl").read_text(encoding="utf-8").splitlines():
        if line.strip():
            trace.append(json.loads(line))

    metrics = scan["metrics"]
    width, height = 1600, 1320
    img = Image.new("RGB", (width, height), (13, 17, 23))
    draw = ImageDraw.Draw(img)

    # Header gradient-ish blocks
    draw.rectangle([0, 0, width, 230], fill=(15, 23, 42))
    draw.ellipse([1050, -320, 1800, 430], fill=(55, 31, 115))
    draw.text((70, 52), "RepoGuardian Agent Dashboard", font=f(52, bold=True), fill=(240, 246, 252))
    draw_wrapped(
        draw,
        "AI codebase health scanner and refactor planning agent. Static analyzer + Risk Analyst + Patch Planner + Test Designer.",
        (74, 126),
        f(24),
        (201, 209, 217),
        1120,
        8,
    )

    # Cards
    y = 270
    gap = 24
    card_w = (width - 140 - gap * 3) // 4
    card(draw, (70, y), (card_w, 150), "Files", metrics["file_count"], "scanned sources")
    card(draw, (70 + (card_w + gap), y), (card_w, 150), "Lines", metrics["line_count"], "LOC inspected")
    card(draw, (70 + 2 * (card_w + gap), y), (card_w, 150), "Findings", metrics["finding_count"], "prioritized risks")
    card(draw, (70 + 3 * (card_w + gap), y), (card_w, 150), "LLM Mode", "offline", "OpenAI-compatible ready")

    # Workflow
    y = 460
    draw.text((70, y), "Agent workflow", font=f(32, bold=True), fill=(240, 246, 252))
    y += 54
    flow_x = 70
    nodes = ["Repository\nScanner", "Risk Analyst\nAgent", "Patch Planner\nAgent", "Test Designer\nAgent", "Dashboard\n+ Issues"]
    node_w, node_h = 238, 92
    for i, node in enumerate(nodes):
        x = flow_x + i * (node_w + 58)
        draw.rounded_rectangle([x, y, x + node_w, y + node_h], radius=20, fill=(22, 27, 34), outline=(79, 70, 229), width=2)
        lines = node.split("\n")
        draw.text((x + 22, y + 20), lines[0], font=f(23, bold=True), fill=(240, 246, 252))
        draw.text((x + 22, y + 52), lines[1], font=f(22), fill=(201, 209, 217))
        if i < len(nodes) - 1:
            ax = x + node_w + 14
            draw.line([ax, y + node_h // 2, ax + 30, y + node_h // 2], fill=(139, 148, 158), width=4)
            draw.polygon([(ax + 30, y + node_h // 2), (ax + 20, y + node_h // 2 - 8), (ax + 20, y + node_h // 2 + 8)], fill=(139, 148, 158))

    # Left panel: distribution
    y = 640
    draw.text((70, y), "Risk distribution", font=f(32, bold=True), fill=(240, 246, 252))
    panel_y = y + 50
    draw.rounded_rectangle([70, panel_y, 760, panel_y + 275], radius=22, fill=(22, 27, 34), outline=(48, 54, 61), width=2)
    draw.text((100, panel_y + 28), "Severity counts", font=f(24, bold=True), fill=(240, 246, 252))
    sev = metrics["severity_counts"]
    sy = panel_y + 72
    colors = {"high": (248, 81, 73), "medium": (210, 153, 34), "low": (56, 189, 248), "critical": (255, 0, 80)}
    for key in ["critical", "high", "medium", "low", "info"]:
        if key not in sev:
            continue
        draw.rounded_rectangle([100, sy, 230, sy + 36], radius=18, fill=colors.get(key, (139, 148, 158)))
        draw.text((122, sy + 4), key, font=f(18, bold=True), fill=(13, 17, 23))
        draw.text((260, sy + 3), str(sev[key]), font=f(24, bold=True), fill=(240, 246, 252))
        sy += 48
    draw.text((430, panel_y + 28), "Category", font=f(24, bold=True), fill=(240, 246, 252))
    cy = panel_y + 72
    for key, val in metrics["category_counts"].items():
        draw.text((430, cy), f"{key}: {val}", font=f(20), fill=(201, 209, 217))
        cy += 36

    # Right panel: generated issues
    draw.text((820, y), "Generated GitHub issues", font=f(32, bold=True), fill=(240, 246, 252))
    panel2_y = y + 50
    draw.rounded_rectangle([820, panel2_y, 1530, panel2_y + 275], radius=22, fill=(22, 27, 34), outline=(48, 54, 61), width=2)
    iy = panel2_y + 24
    for issue in issues[:4]:
        iy = draw_wrapped(draw, "• " + issue["title"], (850, iy), f(20, bold=True), (240, 246, 252), 620, 6)
        labels = ", ".join(issue.get("labels", []))
        iy = draw_wrapped(draw, labels, (878, iy + 4), f(16), (139, 148, 158), 590, 5)
        iy += 18

    # Agent trace
    y = 980
    draw.text((70, y), "Agent trace", font=f(32, bold=True), fill=(240, 246, 252))
    y += 50
    step_w = (width - 140 - 24 * 2) // 3
    for i, step in enumerate(trace[:3]):
        x = 70 + i * (step_w + 24)
        draw.rounded_rectangle([x, y, x + step_w, y + 230], radius=22, fill=(22, 27, 34), outline=(48, 54, 61), width=2)
        draw.ellipse([x + 22, y + 22, x + 66, y + 66], fill=(124, 58, 237))
        draw.text((x + 36, y + 27), str(i + 1), font=f(22, bold=True), fill=(255, 255, 255))
        draw.text((x + 82, y + 22), step["agent"], font=f(24, bold=True), fill=(240, 246, 252))
        token_total = step.get("prompt_tokens_estimate", 0) + step.get("completion_tokens_estimate", 0)
        draw.text((x + 82, y + 56), f"{step['mode']} · ~{token_total} tokens", font=f(18), fill=(139, 148, 158))
        summary = step["output"].replace("\n", " ")
        draw_wrapped(draw, summary[:240] + ("..." if len(summary) > 240 else ""), (x + 24, y + 92), f(18), (201, 209, 217), step_w - 48, 5)

    draw.text((70, height - 54), "Static page is also available at docs/index.html for GitHub Pages publishing.", font=f(20), fill=(139, 148, 158))
    img.save(OUT / "workflow_dashboard.png")


def render_readme_preview():
    width, height = 1280, 880
    img = Image.new("RGB", (width, height), (246, 248, 250))
    draw = ImageDraw.Draw(img)
    draw.rectangle([0, 0, width, 82], fill=(36, 41, 47))
    draw.text((50, 24), "GitHub upload target", font=f(28, bold=True), fill=(255, 255, 255))
    draw.text((50, 120), "repoguardian_agent", font=f(46, bold=True), fill=(36, 41, 47))
    draw.text((50, 180), "AI codebase health and refactor planning agent", font=f(24), fill=(87, 96, 106))
    draw.rounded_rectangle([50, 240, width - 50, 500], radius=18, fill=(255, 255, 255), outline=(208, 215, 222), width=2)
    draw.text((80, 270), "Files ready for GitHub", font=f(26, bold=True), fill=(36, 41, 47))
    rows = [
        "repoguardian/ — source code",
        "sample_repo/ — demo target repository",
        "docs/index.html — GitHub Pages dashboard",
        "screenshots/ — application evidence images",
        "APPLICATION_COPY.md — copy-paste application text",
    ]
    y = 320
    for row in rows:
        draw.text((90, y), "✓ " + row, font=f(24), fill=(31, 136, 61))
        y += 38
    draw.rounded_rectangle([50, 540, width - 50, 750], radius=18, fill=(255, 255, 255), outline=(208, 215, 222), width=2)
    draw.text((80, 570), "Paste these after upload", font=f(26, bold=True), fill=(36, 41, 47))
    draw.text((90, 628), "GitHub repo: https://github.com/<your-username>/repoguardian_agent", font=f(23, mono=True), fill=(9, 105, 218))
    draw.text((90, 672), "GitHub Pages: https://<your-username>.github.io/repoguardian_agent/", font=f(23, mono=True), fill=(9, 105, 218))
    draw.text((50, height - 70), "Replace <your-username> with your real GitHub username after pushing the repo.", font=f(22), fill=(87, 96, 106))
    img.save(OUT / "github_upload_preview.png")


if __name__ == "__main__":
    render_terminal()
    render_dashboard()
    render_readme_preview()
    print("Generated screenshots in", OUT)
