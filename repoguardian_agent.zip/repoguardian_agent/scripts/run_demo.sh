#!/usr/bin/env bash
set -euo pipefail
python -m repoguardian scan sample_repo --out artifacts/demo --offline --clean
python -m repoguardian.demo_server artifacts/demo --port 8000
