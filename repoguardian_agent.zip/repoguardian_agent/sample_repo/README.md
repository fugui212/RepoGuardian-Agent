# Sample Legacy Checkout Service

This small sample repository intentionally contains a few problems so RepoGuardian can demonstrate scanning and agent planning.
