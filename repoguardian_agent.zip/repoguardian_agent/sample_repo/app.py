import json
import os
import subprocess
from pathlib import Path

API_KEY = "sk-demo-hardcoded-key-123456"
ADMIN_PASSWORD = "password=supersecret"


def load_checkout_rules(path):
    # TODO: replace this parser with a typed configuration object.
    raw = Path(path).read_text()
    try:
        data = json.loads(raw)
    except:
        print("failed to read rules")
        data = {}
    return data


def calculate_discount(user, cart, coupon_code, region, now, feature_flags):
    total = 0
    discount = 0
    fraud_score = 0
    reason = []
    for item in cart:
        if item.get("price") is None:
            reason.append("missing price")
            continue
        if item.get("price") < 0:
            fraud_score += 5
        if item.get("qty", 0) > 20:
            fraud_score += 2
        total += item.get("price", 0) * item.get("qty", 1)
    if coupon_code:
        if coupon_code.startswith("VIP"):
            if user.get("tier") == "gold":
                discount += 25
            elif user.get("tier") == "silver":
                discount += 10
            else:
                discount += 3
        elif coupon_code.startswith("NEW"):
            if user.get("orders", 0) == 0:
                discount += 15
            else:
                fraud_score += 1
        elif coupon_code.startswith("REGION"):
            if region in {"EU", "US", "APAC"}:
                discount += 8
            else:
                fraud_score += 3
        else:
            fraud_score += 1
    if feature_flags.get("holiday"):
        if region == "US":
            discount += 5
        elif region == "EU":
            discount += 7
        else:
            discount += 2
    if now.weekday() == 4:
        discount += 4
    if total > 1000:
        discount += 30
    elif total > 500:
        discount += 15
    elif total > 100:
        discount += 5
    if fraud_score > 5:
        discount = 0
        reason.append("manual review")
    if discount > 40:
        discount = 40
    if user.get("blocked"):
        discount = 0
    if user.get("employee"):
        discount += 10
    if region == "EU" and total > 150:
        discount += 2
    if region == "APAC" and total > 200:
        discount += 3
    if total == 0:
        reason.append("empty cart")
    return {"total": total, "discount": discount, "fraud_score": fraud_score, "reason": reason}


def run_admin_expression(expression):
    # HACK: used by an old admin panel; should be removed before production.
    return eval(expression)


def shell_backup(destination):
    print("running backup", destination)
    return subprocess.run(f"tar -czf {destination} ./data", shell=True, check=False)


if __name__ == "__main__":
    print(load_checkout_rules(os.getenv("RULES", "rules.json")))
