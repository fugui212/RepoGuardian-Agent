const token = "secret=front-end-demo-token";

export function renderCart(cart) {
  // FIXME: replace console output with real telemetry before release.
  console.log("cart", cart);
  return cart.items.map((item) => `<li>${item.name}</li>`).join("\n");
}
