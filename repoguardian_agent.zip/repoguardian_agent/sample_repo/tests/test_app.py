from datetime import datetime

from app import calculate_discount


def test_discount_smoke():
    result = calculate_discount(
        {"tier": "gold", "orders": 2},
        [{"price": 100, "qty": 2}],
        "VIP-SALE",
        "US",
        datetime(2026, 1, 2),
        {"holiday": True},
    )
    assert result["discount"] > 0
